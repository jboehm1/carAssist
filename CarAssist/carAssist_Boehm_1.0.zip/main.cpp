//
//  main.cpp
//  CarAssist
//
//  Created by Jean B on 04.06.24.
//
#include <opencv2/opencv.hpp>
#include <iostream>
#include "imageProcessing.hpp"
#include <vector>

int main(int argc, const char * argv[]) {
    
    std::string captureSource("sequence");// images, webcam, video, sequences
    std::cout << "Starting!\n";
    std::vector<cv::String> fn;
    if (captureSource=="images")
        cv::glob("/Users/jeanb/Documents/weiterbildung/cpp/CarAssist/CarAssist/img/*.jpg", fn, false);
    else if (captureSource=="sequence")
        cv::glob("/Users/jeanb/Documents/weiterbildung/cpp/CarAssist/CarAssist/img/20/image_0/*.png", fn, false);
    std::vector<cv::Mat> images;
    size_t count = fn.size();
    std::cout << "Found "<< count<< " images." << std::endl;
    
    for (size_t i=0; i<count; i++)
    {
        cv::Mat img_orig = ImageProcessing::loadImage(fn[i]);
        ImageProcessing::disp(img_orig,"",2);
        cv::Mat img_filtered;
        ImageProcessing::crop(img_orig, img_orig,
                              55);
        ImageProcessing::filter(img_orig, img_filtered);
        ImageProcessing::disp(img_filtered, "lines", 0);
    }
    return 0;
}
