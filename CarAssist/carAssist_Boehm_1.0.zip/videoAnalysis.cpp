//
//  videoAnalysis.cpp
//  CarAssist
//
//  Created by Jean B on 04.06.24.
//

#include "videoAnalysis.hpp"

void VideoAnalysis::capture(){
    
}
