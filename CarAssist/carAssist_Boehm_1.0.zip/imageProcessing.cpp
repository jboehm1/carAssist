//
//  imagePreprocess.cpp
//  CarAssist
//
//  Created by Jean B on 04.06.24.
//

#include "imageProcessing.hpp"
#include <iostream>
#include <vector>

cv::Mat ImageProcessing::loadImage(std::string_view path) {
    cv::Mat img = cv::imread(path.data(), cv::IMREAD_COLOR);
    if (img.empty()) {
        std::cerr << "Could not open or find the image!" << std::endl;
        exit(EXIT_FAILURE);
    }
    return img;
}

void ImageProcessing::disp(const cv::Mat& _img, const std::string& titel, int waitMs) {
    if (_img.empty()) {
        std::cerr << "Input image is empty!" << std::endl;
        return;
    }
    cv::imshow(titel, _img);
    cv::waitKey(waitMs); // Wait indefinitely until a key is pressed
}

void ImageProcessing::crop(const cv::Mat& src, cv::Mat& dst, int cropPercentage) {
    if (src.empty()) {
        std::cerr << "Input image is empty!" << std::endl;
        return;
    }
    if (cropPercentage <= 0 || cropPercentage > 100) {
        std::cerr << "Invalid crop percentage!" << std::endl;
        return;
    }
    int newHeight = src.rows * cropPercentage / 100;
    cv::Rect myROI(0, src.rows - newHeight, src.cols, newHeight);
    dst = src(myROI).clone();
}

void ImageProcessing::filter(const cv::Mat& src, cv::Mat& dst) {
    if (src.empty()) {
        std::cerr << "Input image is empty!" << std::endl;
        return;
    }
    cv::Mat grey, hsv;
    cv::cvtColor(src, grey, cv::COLOR_BGR2GRAY);
    
//    //HSV fitlering
//    cv::cvtColor(src, hsv, cv::COLOR_BGR2HSV);
//    cv::inRange(hsv, cv::Scalar(0, 0, 100), cv::Scalar(255, 255, 255), grey);
//    disp(grey, "hsv filter ",1);
    cv::equalizeHist(grey, grey);
    disp(grey, "nromalized", 1);
    
    // Gaussian Filtering
    cv::GaussianBlur(grey, grey, cv::Size(3, 3), 0);
    
    
    //Canny filtering
    cv::Canny(grey, dst, 80, 160, 3);
    disp(dst, "Canny",1);
    
//    // Morph filtering
//    int morph_elem = 1;
//    int morph_size=2;
//    cv::Mat element = cv::getStructuringElement( morph_elem, cv::Size( 2*morph_size + 1, 2*morph_size+1 ), cv::Point( morph_size, morph_size ) );
//    morphologyEx( grey, grey, cv::MORPH_OPEN, element );
//    morphologyEx( grey, grey, cv::MORPH_CLOSE, element );
//
//     //SOeabel filter
//    cv::Mat grad_x;
//    cv::Sobel(dst, grad_x, CV_16S, 1, 0, 3);//, 3, 1, 1, cv::BORDER_DEFAULT);
//    // converting back to CV_8U
//    convertScaleAbs(grad_x, dst);
//    disp(dst, "Canny and soebel", 1);

    cv::Mat cdst;
    //cv::cvtColor(src, cdst, cv::COLOR_GRAY2BGR);
    cdst = src.clone();
    //cv::cvtColor(grey, cdst, cv::COLOR_GRAY2BGR);
    cdst = src;
    cv::Mat cdst1=cdst.clone();
    std::vector<cv::Vec2f> lines;
    HoughLines(dst, lines, 1, CV_PI / 180, 100, 0, 0);

    for (size_t i = 0; i < lines.size(); i++) { //lines.size()
        float rho = lines[i][0], theta = lines[i][1];
        cv::Point pt1, pt2;
        double a = cos(theta), b = sin(theta);
        double x0 = a * rho, y0 = b * rho;
        pt1.x = cvRound(x0 + 1000 * (-b));
        pt1.y = cvRound(y0 + 1000 * (a));
        pt2.x = cvRound(x0 - 1000 * (-b));
        pt2.y = cvRound(y0 - 1000 * (a));
        line(cdst, pt1, pt2, cv::Scalar(0, 0, 255), 1, cv::LINE_AA);
    }
    
    // Probabilistic Line Transform
     std::vector<cv::Vec4i> linesP; // will hold the results of the detection
     HoughLinesP(dst, linesP, 1, CV_PI/180, 20, 10, 3 ); // runs the actual detection 50 50 10
     // Draw the lines
     for( size_t i = 0; i < linesP.size(); i++ )
     {
     cv::Vec4i l = linesP[i];
     line( cdst1, cv::Point(l[0], l[1]), cv::Point(l[2], l[3]), cv::Scalar(0,255,0), 2, cv::LINE_AA);
     }
    disp(cdst1,"HoughLineP",1);
    
    
    
    
    
    dst = cdst.clone(); // Update the destination with the final result
}
