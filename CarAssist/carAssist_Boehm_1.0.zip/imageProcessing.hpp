//
//  imagePreprocess.hpp
//  CarAssist
//
//  Created by Jean B on 04.06.24.
//

#ifndef imageProcessing_hpp
#define imageProcessing_hpp

#include <stdio.h>

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp> //for cvtColor etc.

class ImageProcessing{
private:
public:
    static cv::Mat loadImage(std::string_view path);
    static void disp( const cv::Mat& _img, const std::string& titel="Image", int wait=0);
    static void filter(const cv::Mat& src, cv::Mat& dst); // Static method for filtering
    static void crop(const cv::Mat& src, cv::Mat& dst, const int cropPercentage);
    
};
#endif /* imageProcessing_hpp */
