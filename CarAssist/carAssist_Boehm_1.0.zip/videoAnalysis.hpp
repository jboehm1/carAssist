//
//  videoAnalysis.hpp
//  CarAssist
//
//  Created by Jean B on 04.06.24.
//

#ifndef videoAnalysis_hpp
#define videoAnalysis_hpp

#include <stdio.h>
class VideoAnalysis{
public:
    void capture();
};
#endif /* videoAnalysis_hpp */
